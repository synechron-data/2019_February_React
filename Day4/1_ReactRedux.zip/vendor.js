import 'react';
import 'react-dom';
import 'prop-types';
import 'react-router-dom';
import 'react-loadable';
import 'redux';
import 'react-redux';
import 'redux-thunk';

import 'jquery';
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap-theme.css';