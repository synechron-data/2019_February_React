import 'react';
import 'react-dom';

import 'jquery';
import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';