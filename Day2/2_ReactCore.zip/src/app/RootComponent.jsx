import React, { Component } from 'react';
import HelloWithState from './1_HelloWithState';
import HelloWithProps from './2_HelloWithProps';
import Button from './3_WithBehavior';
import StateChangeComponent from './4_StateChange';
import CounterRoot from './5_CounterRoot';
import EventComponent from './6_SyntheticEvents';
import AssignmentRoot from './7_Assignment';
import ControlledVsUnControlled from './8_ControlledVsUnControlled';
import CalculatorRoot from './9_Calculator';
import ListRoot from './10_ListComponent';

class RootComponent extends Component {
    constructor() {
        super();
        this.state = { city: "Pune" };
        this.changeCity = this.changeCity.bind(this);
    }

    changeCity() {
        this.setState({ city: "Mumbai" });
    }

    render() {
        return (
            <div className="container">
                {/* <HelloWithState /> */}
                {/* <HelloWithProps fcity={this.state.city} area={'Kothrud'} pin={411038}/> */}
                {/* <Button/> */}
                {/* <div>
                    <h2>Parent State: {this.state.city}</h2>
                    <StateChangeComponent city={this.state.city} change={this.changeCity}/>
                </div> */}
                {/* <CounterRoot/> */}
                {/* <EventComponent/> */}
                {/* <AssignmentRoot/> */}
                {/* <ControlledVsUnControlled/> */}
                {/* <CalculatorRoot/> */}
                <ListRoot/>
            </div>
        );
    }
}

export default RootComponent;
