import React, { Component } from 'react';

class Result extends Component {
    render() {
        return (
            <h2 className="text-info">Result: {this.props.result}</h2>
        );
    }
}

class Button extends Component {
    render() {
        return (
            <button className="btn btn-info" onClick={(e) => {
                this.props.handleClick(this.props.incBy);
            }}>
                Add {this.props.incBy}
            </button>
        );
    }
}

class AssignmentRoot extends Component {
    constructor(props) {
        super(props);
        this.state = { result: 0 };
        this.updateResult = this.updateResult.bind(this);
    }

    updateResult(by) {
        this.setState({ result: this.state.result + by });
    }

    render() {
        return (
            <div>
                <Result result={this.state.result} />
                <Button incBy={5} handleClick={this.updateResult} />
                <Button incBy={10} handleClick={this.updateResult} />
                <Button incBy={15} handleClick={this.updateResult} />
                <Button incBy={20} handleClick={this.updateResult} />
            </div>
        );
    }
}

export default AssignmentRoot;