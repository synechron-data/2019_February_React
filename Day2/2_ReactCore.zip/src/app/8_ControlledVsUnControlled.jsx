import React, { Component } from 'react';

class ControlledVsUnControlled extends Component {
    constructor(props) {
        super(props);
        this.state = { name: "Manish" };
        this.handleChange = this.handleChange.bind(this);
        this.handleClick = this.handleClick.bind(this);
    }

    handleChange(e) {
        this.setState({ name: e.target.value });
    }

    handleClick(e) {
        this.setState({ name: this.refs.t1.value });
    }

    render() {
        return (
            <div>
                <input type="text" value="Abhijeet" readOnly />
                <br />
                <input type="text" value={this.state.name} readOnly />
                <br />
                <input type="text" defaultValue={this.state.name} />
                <br />
                <input type="text" value={this.state.name} onChange={this.handleChange} />
                <h3>Hello, {this.state.name}</h3>
                <input type="text" ref="t1" />
                <br />
                <button onClick={this.handleClick}>Click</button>
            </div>
        );
    }
}

export default ControlledVsUnControlled;