import React, { Component } from 'react';

class HelloWithProps extends Component {
    constructor(props) {
        super(props);
        // console.log("Ctor: ", this.props);
        // this.state = Object.assign({}, this.props);
        this.state = { ...this.props };
        console.log(this.state);
    }

    render() {
        console.log("Render: ", this.props);

        // this.props.fcity = "Mumbai";

        return (
            <div>
                <h2 className="text-info">You are from: {this.props.fcity}</h2>
            </div>
        );
    }
}

export default HelloWithProps;