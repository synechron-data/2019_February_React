import React, { Component } from 'react';

class StateChangeComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { id: 1, count: 1, ...this.props };
        this.handleClick = this.handleClick.bind(this);
        this.handleClick1 = this.handleClick1.bind(this);
    }

    handleClick() {
        // console.log("handleClick - ", this);
        // this.state.count += 1;
        // console.log(this.state);

        this.setState({ count: this.state.count + 1, city: this.state.city + 1 }, () => {
            console.log(this.state);
        });
    }

    handleClick1(){
        this.props.change();
    }

    render() {
        return (
            <div>
                <hr />
                <h3>Child Prop: {this.props.city}</h3>
                <h3>Child State: {this.state.city}</h3>
                <h3>Id: {this.state.id}</h3>
                <h3>Count: {this.state.count}</h3>
                {/* <button className="btn btn-info" onClick={this.handleClick.bind(this)}>Click Me</button> */}
                <button className="btn btn-info" onClick={this.handleClick}>Click Me</button>
                <button className="btn btn-danger" onClick={this.handleClick1}>Click Me</button>
            </div>
        );
    }
}

export default StateChangeComponent;