import 'react';
import 'react-dom';
import 'prop-types';
import 'react-bootstrap';
import 'react-router-dom';
import 'react-loadable';

import 'jquery';
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap-theme.css';