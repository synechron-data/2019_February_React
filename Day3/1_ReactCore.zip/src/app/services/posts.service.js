const url = "https://jsonplaceholder.typicode.com/posts";

const postAPIClient = {
    getPosts: function (successCB, errorCB) {
        $.getJSON(url).done((data) => {
            successCB(data);
        }).fail((err) => {
            errorCB("Connection Error....");
        });
    },
    getPostsUsingPromise: function () {
        var promise = new Promise((resolve, reject) => {
            $.getJSON(url).done((data) => {
                resolve(data);
            }).fail((err) => {
                reject("Connection Error....");
            });
        });
        return promise;
    }
};

export default postAPIClient;