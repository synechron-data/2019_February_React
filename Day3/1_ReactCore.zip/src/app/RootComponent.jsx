import React, { Component } from 'react';
import Assignment from './1_Assignment';
import PTRoot from './2_PropTypes';
import ErrorHandler from './common/ErrorHandler';
import AjaxComponent from './3_AjaxComponent';
import PropForwardComponent from './4_PropForwarding';
import ParentComponent from './5_ContextAPI';

class RootComponent extends Component {
    constructor() {
        super();
    }

    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <Assignment/> */}
                    {/* <PTRoot /> */}
                    {/* <AjaxComponent/> */}
                    {/* <PropForwardComponent/> */}
                    <ParentComponent/>
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;
