import React, { Component } from 'react';
import DataTable from './common/DataTable';
import postAPIClient from './services/posts.service';

class PropForwardComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            posts: [],
            message: "Loading Data, please wait..."
        }
    }

    render() {
        return (
            <div>
                <h2 className="text-info">{this.state.message}</h2>
                <h3>Ajax Component</h3>
                <Child1 items={this.state.posts}/>
            </div>
        );
    }

    componentDidMount() {
        postAPIClient.getPostsUsingPromise().then((data) => {
            this.setState({ posts: [...data] }, () => {
                this.setState({ message: "" });
            });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        });
    }
}

class Child1 extends Component {
    render() {
        return (
            <div>
                <h3>Child 1</h3>
                <Child2 items={this.props.items}/>
            </div>
        );
    }
}

class Child2 extends Component {
    render() {
        return (
            <div>
                <h3>Child 2</h3>
                <DataTable items={this.props.items} />
            </div>
        );
    }
}



export default PropForwardComponent;