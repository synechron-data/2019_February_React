import React, { Component } from 'react';

import './ComponentTwo.css';

class ComponentTwo extends Component {
    render() {
        return (
            <h1 className="text-success card2">Hello from Component Two!</h1>
        );
    }
}

export default ComponentTwo;


// import React, { Component } from 'react';

// class ComponentTwo extends Component {
//     render() {
//         const card2 = {
//             margin: '1em',
//             paddingLeft: 0,
//             border: '2px dashed green'
//         };

//         return (
//             <h1 style={card2} className="text-success">Hello from Component Two!</h1>
//         );
//     }
// }

// export default ComponentTwo;
