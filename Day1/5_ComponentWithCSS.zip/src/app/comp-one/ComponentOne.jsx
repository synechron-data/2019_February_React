import React, { Component } from 'react';

import './ComponentOne.css';

class ComponentOne extends Component {
    render() {
        return (
            <h1 className="text-info card1">Hello from Component One!</h1>
        );
    }
}

export default ComponentOne;


// import React, { Component } from 'react';

// class ComponentOne extends Component {
//     render() {
//         const card1 = {
//             margin: '1em',
//             paddingLeft: 0,
//             border: '2px solid blue'
//         };

//         return (
//             <h1 style={card1} className="text-info">Hello from Component One!</h1>
//         );
//     }
// }

// export default ComponentOne;
