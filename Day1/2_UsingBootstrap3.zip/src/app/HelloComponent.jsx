import React, { Component } from 'react';

class Hello extends Component {
    render() {
        return (
            <h1 className="text-info">Hello World!</h1>
        );
    }
}

export default Hello;
