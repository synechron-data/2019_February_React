import React, { Component } from 'react';

import ComponentOne from './ComponentOne';
import ComponentTwo from './ComponentTwo';

// class RootComponent extends Component {
//     render() {
//         return (
//             <div className="container">
//                 <ComponentOne/>
//                 <ComponentTwo/>
//             </div>
//         );
//     }
// }

// const RootComponent = () => {
//     return (
//         <div className="container">
//             <ComponentOne />
//             <ComponentTwo />
//         </div>
//     );
// };

const RootComponent = () => (
    <div className="container">
        <ComponentOne />
        <ComponentTwo />
    </div>
);

export default RootComponent;
