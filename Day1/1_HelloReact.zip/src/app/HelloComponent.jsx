import React, { Component } from 'react';

const Hello = () => <h1>Hello World!</h1>;

// const Hello = () => {
//     return (
//         <h1>Hello World!</h1>
//     );
// }

export default Hello;
// ----------------------------------------------
// import React, { Component } from 'react';

// class Hello extends Component {
//     render() {
//         return (
//             <h1>Hello World!</h1>
//         );
//     }
// }

// export default Hello;
// -----------------------------------------------
// import React from 'react';

// class Hello extends React.Component {
//     render() {
//         return (
//             <h1>Hello World!</h1>
//         );
//     }
// }

// export default Hello;